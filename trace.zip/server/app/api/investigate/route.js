/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/investigate/route";
exports.ids = ["app/api/investigate/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/***/ ((module) => {

"use strict";
module.exports = require("child_process");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "fs/promises":
/*!******************************!*\
  !*** external "fs/promises" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("fs/promises");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "worker_threads":
/*!*********************************!*\
  !*** external "worker_threads" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("worker_threads");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ "node:buffer":
/*!******************************!*\
  !*** external "node:buffer" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:buffer");

/***/ }),

/***/ "node:fs":
/*!**************************!*\
  !*** external "node:fs" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:fs");

/***/ }),

/***/ "node:http":
/*!****************************!*\
  !*** external "node:http" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:http");

/***/ }),

/***/ "node:https":
/*!*****************************!*\
  !*** external "node:https" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:https");

/***/ }),

/***/ "node:net":
/*!***************************!*\
  !*** external "node:net" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:net");

/***/ }),

/***/ "node:path":
/*!****************************!*\
  !*** external "node:path" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:path");

/***/ }),

/***/ "node:process":
/*!*******************************!*\
  !*** external "node:process" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:process");

/***/ }),

/***/ "node:stream":
/*!******************************!*\
  !*** external "node:stream" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream");

/***/ }),

/***/ "node:stream/promises":
/*!***************************************!*\
  !*** external "node:stream/promises" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/promises");

/***/ }),

/***/ "node:stream/web":
/*!**********************************!*\
  !*** external "node:stream/web" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:stream/web");

/***/ }),

/***/ "node:url":
/*!***************************!*\
  !*** external "node:url" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:url");

/***/ }),

/***/ "node:util":
/*!****************************!*\
  !*** external "node:util" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:util");

/***/ }),

/***/ "node:zlib":
/*!****************************!*\
  !*** external "node:zlib" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:zlib");

/***/ }),

/***/ "?32c4":
/*!****************************!*\
  !*** bufferutil (ignored) ***!
  \****************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "?66e9":
/*!********************************!*\
  !*** utf-8-validate (ignored) ***!
  \********************************/
/***/ (() => {

/* (ignored) */

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Finvestigate%2Froute&page=%2Fapi%2Finvestigate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvestigate%2Froute.ts&appDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Finvestigate%2Froute&page=%2Fapi%2Finvestigate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvestigate%2Froute.ts&appDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_AKSHAYA_Downloads_tracepilot_nextjs_1_tracepilot_nextjs_app_api_investigate_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/investigate/route.ts */ \"(rsc)/./app/api/investigate/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/investigate/route\",\n        pathname: \"/api/investigate\",\n        filename: \"route\",\n        bundlePath: \"app/api/investigate/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\AKSHAYA\\\\Downloads\\\\tracepilot-nextjs (1)\\\\tracepilot-nextjs\\\\app\\\\api\\\\investigate\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_AKSHAYA_Downloads_tracepilot_nextjs_1_tracepilot_nextjs_app_api_investigate_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/investigate/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZpbnZlc3RpZ2F0ZSUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGaW52ZXN0aWdhdGUlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZpbnZlc3RpZ2F0ZSUyRnJvdXRlLnRzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNBS1NIQVlBJTVDRG93bmxvYWRzJTVDdHJhY2VwaWxvdC1uZXh0anMlMjAoMSklNUN0cmFjZXBpbG90LW5leHRqcyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDQUtTSEFZQSU1Q0Rvd25sb2FkcyU1Q3RyYWNlcGlsb3QtbmV4dGpzJTIwKDEpJTVDdHJhY2VwaWxvdC1uZXh0anMmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFzRztBQUN2QztBQUNjO0FBQ3dEO0FBQ3JJO0FBQ0E7QUFDQTtBQUNBLHdCQUF3QixnSEFBbUI7QUFDM0M7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsaUVBQWlFO0FBQ3pFO0FBQ0E7QUFDQSxXQUFXLDRFQUFXO0FBQ3RCO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDdUg7O0FBRXZIIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vdHJhY2VwaWxvdC8/MDMyNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBSb3V0ZVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvYXBwLXJvdXRlL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCJDOlxcXFxVc2Vyc1xcXFxBS1NIQVlBXFxcXERvd25sb2Fkc1xcXFx0cmFjZXBpbG90LW5leHRqcyAoMSlcXFxcdHJhY2VwaWxvdC1uZXh0anNcXFxcYXBwXFxcXGFwaVxcXFxpbnZlc3RpZ2F0ZVxcXFxyb3V0ZS50c1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvaW52ZXN0aWdhdGUvcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9pbnZlc3RpZ2F0ZVwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvaW52ZXN0aWdhdGUvcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJDOlxcXFxVc2Vyc1xcXFxBS1NIQVlBXFxcXERvd25sb2Fkc1xcXFx0cmFjZXBpbG90LW5leHRqcyAoMSlcXFxcdHJhY2VwaWxvdC1uZXh0anNcXFxcYXBwXFxcXGFwaVxcXFxpbnZlc3RpZ2F0ZVxcXFxyb3V0ZS50c1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9hcGkvaW52ZXN0aWdhdGUvcm91dGVcIjtcbmZ1bmN0aW9uIHBhdGNoRmV0Y2goKSB7XG4gICAgcmV0dXJuIF9wYXRjaEZldGNoKHtcbiAgICAgICAgc2VydmVySG9va3MsXG4gICAgICAgIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2VcbiAgICB9KTtcbn1cbmV4cG9ydCB7IHJvdXRlTW9kdWxlLCByZXF1ZXN0QXN5bmNTdG9yYWdlLCBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcywgb3JpZ2luYWxQYXRobmFtZSwgcGF0Y2hGZXRjaCwgIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFwcC1yb3V0ZS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Finvestigate%2Froute&page=%2Fapi%2Finvestigate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvestigate%2Froute.ts&appDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/investigate/route.ts":
/*!**************************************!*\
  !*** ./app/api/investigate/route.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   POST: () => (/* binding */ POST)\n/* harmony export */ });\n/* harmony import */ var _google_genai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @google/genai */ \"(rsc)/./node_modules/@google/genai/dist/node/index.mjs\");\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n\n\nfunction parseTrace(logs) {\n    return logs.split(/\\r?\\n/).filter(Boolean).slice(0, 100).map((line, index)=>{\n        const match = line.match(/^(\\d{2}:\\d{2}:\\d{2})\\s+(INFO|WARN|WARNING|ERROR|DEBUG)\\s+(.*)$/i);\n        if (match) {\n            return {\n                time: match[1],\n                level: match[2].toUpperCase() === \"WARNING\" ? \"WARN\" : match[2].toUpperCase(),\n                message: match[3]\n            };\n        }\n        return {\n            time: `event-${String(index + 1).padStart(2, \"0\")}`,\n            level: /error|failed|exception|timeout/i.test(line) ? \"ERROR\" : \"INFO\",\n            message: line\n        };\n    });\n}\nasync function POST(request) {\n    try {\n        const body = await request.json();\n        const logs = typeof body.logs === \"string\" ? body.logs.trim() : \"\";\n        if (!logs) return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json({\n            error: \"Please provide a trace to investigate.\"\n        }, {\n            status: 400\n        });\n        if (logs.length > 30000) return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json({\n            error: \"Trace is too long. Please keep it under 30,000 characters.\"\n        }, {\n            status: 413\n        });\n        const lower = logs.toLowerCase();\n        const findings = [];\n        let rootCause = \"No obvious failure pattern detected\";\n        let summary = \"The trace does not contain a clear timeout, tool error, retry loop, or output-validation failure. Review the surrounding application context.\";\n        if (lower.includes(\"timeout\") || lower.includes(\"timed out\")) {\n            rootCause = \"A tool or downstream service timed out\";\n            summary = \"The trace contains timeout language. The agent may be waiting on a slow or unavailable dependency.\";\n            findings.push({\n                severity: \"high\",\n                title: \"Timeout detected\",\n                detail: \"At least one event indicates that a tool or dependency exceeded its time limit.\",\n                recommendation: \"Check dependency health and latency. Set a bounded timeout, emit duration metrics, and consider a fallback for this tool.\"\n            });\n        }\n        if (lower.includes(\"retry\") || lower.includes(\"retries\")) {\n            findings.push({\n                severity: \"medium\",\n                title: \"Retry behavior detected\",\n                detail: \"The trace mentions a retry. Repeated retries can amplify latency when the underlying failure is persistent.\",\n                recommendation: \"Use capped exponential backoff with jitter, and retry only errors that are safe to repeat.\"\n            });\n        }\n        if (lower.includes(\"invalid json\") || lower.includes(\"schema\") || lower.includes(\"parse error\")) {\n            rootCause = \"The agent output may not match the expected structure\";\n            summary = \"The trace suggests a structured-output parsing or validation problem.\";\n            findings.push({\n                severity: \"high\",\n                title: \"Structured output validation issue\",\n                detail: \"A JSON, schema, or parsing error appears in the trace.\",\n                recommendation: \"Validate model output at the boundary, return the validation error to the agent, and cap repair attempts.\"\n            });\n        }\n        if (lower.includes(\"permission\") || lower.includes(\"unauthorized\") || lower.includes(\"403\")) {\n            findings.push({\n                severity: \"high\",\n                title: \"Authorization issue detected\",\n                detail: \"The trace includes a permission or authorization failure.\",\n                recommendation: \"Verify the runtime identity, tool scopes, and resource-level permissions. Avoid logging secrets or tokens.\"\n            });\n            if (!lower.includes(\"timeout\")) {\n                rootCause = \"A tool call may be blocked by authorization\";\n                summary = \"The trace includes a permission-related failure that may prevent the agent from using a tool.\";\n            }\n        }\n        if (lower.includes(\"loop\") || lower.includes(\"maximum steps\") || lower.includes(\"max iterations\")) {\n            findings.push({\n                severity: \"medium\",\n                title: \"Possible agent loop or step-limit hit\",\n                detail: \"The trace suggests repeated actions or a maximum-step limit.\",\n                recommendation: \"Add a clear stop condition, detect repeated tool/action pairs, and log the agent's current goal.\"\n            });\n            if (!lower.includes(\"timeout\")) {\n                rootCause = \"The agent may be stuck repeating actions\";\n                summary = \"The trace suggests a loop or a run that reached its step limit.\";\n            }\n        }\n        if (findings.length === 0) {\n            findings.push({\n                severity: \"low\",\n                title: \"No matching signature found\",\n                detail: \"The current prototype checks a small set of common failure patterns.\",\n                recommendation: \"Include the full tool request/response, exception message, and run ID to make the trace more actionable.\"\n            });\n        }\n        // Gemini adds an AI investigation; existing rule-based results remain the fallback.\n        let aiSummary = summary;\n        let aiRootCause = rootCause;\n        let aiFindings = findings;\n        try {\n            const ai = new _google_genai__WEBPACK_IMPORTED_MODULE_0__.GoogleGenAI({\n                apiKey: process.env.GEMINI_API_KEY\n            });\n            const response = await ai.models.generateContent({\n                model: \"gemini-3.1-flash-lite\",\n                contents: `\nYou are TracePilot, an application trace investigator.\nAnalyze the logs below. Use only evidence present in the logs.\nDo not invent events or claim certainty when the evidence is inconclusive.\nReturn ONLY valid JSON with this exact shape:\n{\n  \"summary\": \"brief explanation\",\n  \"rootCause\": \"likely cause, or say it is unclear\",\n  \"findings\": [\n    {\n      \"severity\": \"high\",\n      \"title\": \"short title\",\n      \"detail\": \"evidence from the trace\",\n      \"recommendation\": \"next debugging step\"\n    }\n  ]\n}\nSeverity must be \"high\", \"medium\", or \"low\".\nIf there is no clear issue, return one low-severity finding.\n\nLogs:\n${logs}\n        `,\n                config: {\n                    responseMimeType: \"application/json\"\n                }\n            });\n            const text = response.text;\n            if (text) {\n                const parsed = JSON.parse(text);\n                if (typeof parsed.summary === \"string\" && typeof parsed.rootCause === \"string\" && Array.isArray(parsed.findings)) {\n                    aiSummary = parsed.summary;\n                    aiRootCause = parsed.rootCause;\n                    aiFindings = parsed.findings;\n                }\n            }\n        } catch (error) {\n            // Keep the rule-based analysis if Gemini is unavailable or returns invalid data.\n            console.error(\"Gemini investigation failed:\", error);\n        }\n        const trace = parseTrace(logs).slice(-30);\n        const errorCount = trace.filter((e)=>e.level === \"ERROR\").length;\n        const runId = `TP-${Date.now().toString(36).toUpperCase()}`;\n        return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json({\n            runId,\n            status: errorCount ? \"needs_attention\" : \"reviewed\",\n            summary: aiSummary,\n            rootCause: aiRootCause,\n            findings: aiFindings,\n            trace\n        });\n    } catch  {\n        return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json({\n            error: \"Invalid request. Send JSON with a logs string.\"\n        }, {\n            status: 400\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2ludmVzdGlnYXRlL3JvdXRlLnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUE0QztBQUNZO0FBU3hELFNBQVNFLFdBQVdDLElBQVk7SUFDOUIsT0FBT0EsS0FBS0MsS0FBSyxDQUFDLFNBQVNDLE1BQU0sQ0FBQ0MsU0FBU0MsS0FBSyxDQUFDLEdBQUcsS0FBS0MsR0FBRyxDQUFDLENBQUNDLE1BQU1DO1FBQ2xFLE1BQU1DLFFBQVFGLEtBQUtFLEtBQUssQ0FBQztRQUN6QixJQUFJQSxPQUFPO1lBQ1QsT0FBTztnQkFBRUMsTUFBTUQsS0FBSyxDQUFDLEVBQUU7Z0JBQUVFLE9BQU9GLEtBQUssQ0FBQyxFQUFFLENBQUNHLFdBQVcsT0FBTyxZQUFZLFNBQVNILEtBQUssQ0FBQyxFQUFFLENBQUNHLFdBQVc7Z0JBQUlDLFNBQVNKLEtBQUssQ0FBQyxFQUFFO1lBQUM7UUFDNUg7UUFDQSxPQUFPO1lBQUVDLE1BQU0sQ0FBQyxNQUFNLEVBQUVJLE9BQU9OLFFBQVEsR0FBR08sUUFBUSxDQUFDLEdBQUcsS0FBSyxDQUFDO1lBQUVKLE9BQU8sa0NBQWtDSyxJQUFJLENBQUNULFFBQVEsVUFBVTtZQUFRTSxTQUFTTjtRQUFLO0lBQ3RKO0FBQ0Y7QUFFTyxlQUFlVSxLQUFLQyxPQUFvQjtJQUM3QyxJQUFJO1FBQ0YsTUFBTUMsT0FBTyxNQUFNRCxRQUFRRSxJQUFJO1FBQy9CLE1BQU1uQixPQUFPLE9BQU9rQixLQUFLbEIsSUFBSSxLQUFLLFdBQVdrQixLQUFLbEIsSUFBSSxDQUFDb0IsSUFBSSxLQUFLO1FBQ2hFLElBQUksQ0FBQ3BCLE1BQU0sT0FBT0YscURBQVlBLENBQUNxQixJQUFJLENBQUM7WUFBRUUsT0FBTztRQUF5QyxHQUFHO1lBQUVDLFFBQVE7UUFBSTtRQUN2RyxJQUFJdEIsS0FBS3VCLE1BQU0sR0FBRyxPQUFPLE9BQU96QixxREFBWUEsQ0FBQ3FCLElBQUksQ0FBQztZQUFFRSxPQUFPO1FBQTZELEdBQUc7WUFBRUMsUUFBUTtRQUFJO1FBRXpJLE1BQU1FLFFBQVF4QixLQUFLeUIsV0FBVztRQUM5QixNQUFNQyxXQUFzQixFQUFFO1FBQzlCLElBQUlDLFlBQVk7UUFDaEIsSUFBSUMsVUFBVTtRQUVkLElBQUlKLE1BQU1LLFFBQVEsQ0FBQyxjQUFjTCxNQUFNSyxRQUFRLENBQUMsY0FBYztZQUM1REYsWUFBWTtZQUNaQyxVQUFVO1lBQ1ZGLFNBQVNJLElBQUksQ0FBQztnQkFDWkMsVUFBVTtnQkFDVkMsT0FBTztnQkFDUEMsUUFBUTtnQkFDUkMsZ0JBQWdCO1lBQ2xCO1FBQ0Y7UUFDQSxJQUFJVixNQUFNSyxRQUFRLENBQUMsWUFBWUwsTUFBTUssUUFBUSxDQUFDLFlBQVk7WUFDeERILFNBQVNJLElBQUksQ0FBQztnQkFDWkMsVUFBVTtnQkFDVkMsT0FBTztnQkFDUEMsUUFBUTtnQkFDUkMsZ0JBQWdCO1lBQ2xCO1FBQ0Y7UUFDQSxJQUFJVixNQUFNSyxRQUFRLENBQUMsbUJBQW1CTCxNQUFNSyxRQUFRLENBQUMsYUFBYUwsTUFBTUssUUFBUSxDQUFDLGdCQUFnQjtZQUMvRkYsWUFBWTtZQUNaQyxVQUFVO1lBQ1ZGLFNBQVNJLElBQUksQ0FBQztnQkFDWkMsVUFBVTtnQkFDVkMsT0FBTztnQkFDUEMsUUFBUTtnQkFDUkMsZ0JBQWdCO1lBQ2xCO1FBQ0Y7UUFDQSxJQUFJVixNQUFNSyxRQUFRLENBQUMsaUJBQWlCTCxNQUFNSyxRQUFRLENBQUMsbUJBQW1CTCxNQUFNSyxRQUFRLENBQUMsUUFBUTtZQUMzRkgsU0FBU0ksSUFBSSxDQUFDO2dCQUNaQyxVQUFVO2dCQUNWQyxPQUFPO2dCQUNQQyxRQUFRO2dCQUNSQyxnQkFBZ0I7WUFDbEI7WUFDQSxJQUFJLENBQUNWLE1BQU1LLFFBQVEsQ0FBQyxZQUFZO2dCQUM5QkYsWUFBWTtnQkFDWkMsVUFBVTtZQUNaO1FBQ0Y7UUFDQSxJQUFJSixNQUFNSyxRQUFRLENBQUMsV0FBV0wsTUFBTUssUUFBUSxDQUFDLG9CQUFvQkwsTUFBTUssUUFBUSxDQUFDLG1CQUFtQjtZQUNqR0gsU0FBU0ksSUFBSSxDQUFDO2dCQUNaQyxVQUFVO2dCQUNWQyxPQUFPO2dCQUNQQyxRQUFRO2dCQUNSQyxnQkFBZ0I7WUFDbEI7WUFDQSxJQUFJLENBQUNWLE1BQU1LLFFBQVEsQ0FBQyxZQUFZO2dCQUM5QkYsWUFBWTtnQkFDWkMsVUFBVTtZQUNaO1FBQ0Y7UUFDQSxJQUFJRixTQUFTSCxNQUFNLEtBQUssR0FBRztZQUN6QkcsU0FBU0ksSUFBSSxDQUFDO2dCQUNaQyxVQUFVO2dCQUNWQyxPQUFPO2dCQUNQQyxRQUFRO2dCQUNSQyxnQkFBZ0I7WUFDbEI7UUFDRjtRQUNJLG9GQUFvRjtRQUN4RixJQUFJQyxZQUFZUDtRQUNoQixJQUFJUSxjQUFjVDtRQUNsQixJQUFJVSxhQUFhWDtRQUVqQixJQUFJO1lBQ0YsTUFBTVksS0FBSyxJQUFJekMsc0RBQVdBLENBQUM7Z0JBQ3pCMEMsUUFBUUMsUUFBUUMsR0FBRyxDQUFDQyxjQUFjO1lBQ3BDO1lBRUEsTUFBTUMsV0FBVyxNQUFNTCxHQUFHTSxNQUFNLENBQUNDLGVBQWUsQ0FBQztnQkFDL0NDLE9BQU87Z0JBQ1BDLFVBQVUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJuQixFQUFFL0MsS0FBSztRQUNDLENBQUM7Z0JBQ0RnRCxRQUFRO29CQUNOQyxrQkFBa0I7Z0JBQ3BCO1lBQ0Y7WUFFQSxNQUFNQyxPQUFPUCxTQUFTTyxJQUFJO1lBQzFCLElBQUlBLE1BQU07Z0JBQ1IsTUFBTUMsU0FBU0MsS0FBS0MsS0FBSyxDQUFDSDtnQkFFMUIsSUFDRSxPQUFPQyxPQUFPdkIsT0FBTyxLQUFLLFlBQzFCLE9BQU91QixPQUFPeEIsU0FBUyxLQUFLLFlBQzVCMkIsTUFBTUMsT0FBTyxDQUFDSixPQUFPekIsUUFBUSxHQUM3QjtvQkFDQVMsWUFBWWdCLE9BQU92QixPQUFPO29CQUMxQlEsY0FBY2UsT0FBT3hCLFNBQVM7b0JBQzlCVSxhQUFhYyxPQUFPekIsUUFBUTtnQkFDOUI7WUFDRjtRQUNGLEVBQUUsT0FBT0wsT0FBTztZQUNkLGlGQUFpRjtZQUNqRm1DLFFBQVFuQyxLQUFLLENBQUMsZ0NBQWdDQTtRQUNoRDtRQUNBLE1BQU1vQyxRQUFRMUQsV0FBV0MsTUFBTUksS0FBSyxDQUFDLENBQUM7UUFDdEMsTUFBTXNELGFBQWFELE1BQU12RCxNQUFNLENBQUN5RCxDQUFBQSxJQUFLQSxFQUFFakQsS0FBSyxLQUFLLFNBQVNhLE1BQU07UUFDaEUsTUFBTXFDLFFBQVEsQ0FBQyxHQUFHLEVBQUVDLEtBQUtDLEdBQUcsR0FBR0MsUUFBUSxDQUFDLElBQUlwRCxXQUFXLEdBQUcsQ0FBQztRQUUzRCxPQUFPYixxREFBWUEsQ0FBQ3FCLElBQUksQ0FBQztZQUN2QnlDO1lBQ0F0QyxRQUFRb0MsYUFBYSxvQkFBb0I7WUFDekM5QixTQUFTTztZQUNUUixXQUFXUztZQUNYVixVQUFVVztZQUNWb0I7UUFDRjtJQUNGLEVBQUUsT0FBTTtRQUNOLE9BQU8zRCxxREFBWUEsQ0FBQ3FCLElBQUksQ0FBQztZQUFFRSxPQUFPO1FBQWlELEdBQUc7WUFBRUMsUUFBUTtRQUFJO0lBQ3RHO0FBQ0YiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly90cmFjZXBpbG90Ly4vYXBwL2FwaS9pbnZlc3RpZ2F0ZS9yb3V0ZS50cz8yZGYzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdvb2dsZUdlbkFJIH0gZnJvbSBcIkBnb29nbGUvZ2VuYWlcIjtcbmltcG9ydCB7IE5leHRSZXF1ZXN0LCBOZXh0UmVzcG9uc2UgfSBmcm9tIFwibmV4dC9zZXJ2ZXJcIjtcblxudHlwZSBGaW5kaW5nID0ge1xuICBzZXZlcml0eTogXCJoaWdoXCIgfCBcIm1lZGl1bVwiIHwgXCJsb3dcIjtcbiAgdGl0bGU6IHN0cmluZztcbiAgZGV0YWlsOiBzdHJpbmc7XG4gIHJlY29tbWVuZGF0aW9uOiBzdHJpbmc7XG59O1xuXG5mdW5jdGlvbiBwYXJzZVRyYWNlKGxvZ3M6IHN0cmluZykge1xuICByZXR1cm4gbG9ncy5zcGxpdCgvXFxyP1xcbi8pLmZpbHRlcihCb29sZWFuKS5zbGljZSgwLCAxMDApLm1hcCgobGluZSwgaW5kZXgpID0+IHtcbiAgICBjb25zdCBtYXRjaCA9IGxpbmUubWF0Y2goL14oXFxkezJ9OlxcZHsyfTpcXGR7Mn0pXFxzKyhJTkZPfFdBUk58V0FSTklOR3xFUlJPUnxERUJVRylcXHMrKC4qKSQvaSk7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICByZXR1cm4geyB0aW1lOiBtYXRjaFsxXSwgbGV2ZWw6IG1hdGNoWzJdLnRvVXBwZXJDYXNlKCkgPT09IFwiV0FSTklOR1wiID8gXCJXQVJOXCIgOiBtYXRjaFsyXS50b1VwcGVyQ2FzZSgpLCBtZXNzYWdlOiBtYXRjaFszXSB9O1xuICAgIH1cbiAgICByZXR1cm4geyB0aW1lOiBgZXZlbnQtJHtTdHJpbmcoaW5kZXggKyAxKS5wYWRTdGFydCgyLCBcIjBcIil9YCwgbGV2ZWw6IC9lcnJvcnxmYWlsZWR8ZXhjZXB0aW9ufHRpbWVvdXQvaS50ZXN0KGxpbmUpID8gXCJFUlJPUlwiIDogXCJJTkZPXCIsIG1lc3NhZ2U6IGxpbmUgfTtcbiAgfSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQT1NUKHJlcXVlc3Q6IE5leHRSZXF1ZXN0KSB7XG4gIHRyeSB7XG4gICAgY29uc3QgYm9keSA9IGF3YWl0IHJlcXVlc3QuanNvbigpO1xuICAgIGNvbnN0IGxvZ3MgPSB0eXBlb2YgYm9keS5sb2dzID09PSBcInN0cmluZ1wiID8gYm9keS5sb2dzLnRyaW0oKSA6IFwiXCI7XG4gICAgaWYgKCFsb2dzKSByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oeyBlcnJvcjogXCJQbGVhc2UgcHJvdmlkZSBhIHRyYWNlIHRvIGludmVzdGlnYXRlLlwiIH0sIHsgc3RhdHVzOiA0MDAgfSk7XG4gICAgaWYgKGxvZ3MubGVuZ3RoID4gMzAwMDApIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IGVycm9yOiBcIlRyYWNlIGlzIHRvbyBsb25nLiBQbGVhc2Uga2VlcCBpdCB1bmRlciAzMCwwMDAgY2hhcmFjdGVycy5cIiB9LCB7IHN0YXR1czogNDEzIH0pO1xuXG4gICAgY29uc3QgbG93ZXIgPSBsb2dzLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgZmluZGluZ3M6IEZpbmRpbmdbXSA9IFtdO1xuICAgIGxldCByb290Q2F1c2UgPSBcIk5vIG9idmlvdXMgZmFpbHVyZSBwYXR0ZXJuIGRldGVjdGVkXCI7XG4gICAgbGV0IHN1bW1hcnkgPSBcIlRoZSB0cmFjZSBkb2VzIG5vdCBjb250YWluIGEgY2xlYXIgdGltZW91dCwgdG9vbCBlcnJvciwgcmV0cnkgbG9vcCwgb3Igb3V0cHV0LXZhbGlkYXRpb24gZmFpbHVyZS4gUmV2aWV3IHRoZSBzdXJyb3VuZGluZyBhcHBsaWNhdGlvbiBjb250ZXh0LlwiO1xuXG4gICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwidGltZW91dFwiKSB8fCBsb3dlci5pbmNsdWRlcyhcInRpbWVkIG91dFwiKSkge1xuICAgICAgcm9vdENhdXNlID0gXCJBIHRvb2wgb3IgZG93bnN0cmVhbSBzZXJ2aWNlIHRpbWVkIG91dFwiO1xuICAgICAgc3VtbWFyeSA9IFwiVGhlIHRyYWNlIGNvbnRhaW5zIHRpbWVvdXQgbGFuZ3VhZ2UuIFRoZSBhZ2VudCBtYXkgYmUgd2FpdGluZyBvbiBhIHNsb3cgb3IgdW5hdmFpbGFibGUgZGVwZW5kZW5jeS5cIjtcbiAgICAgIGZpbmRpbmdzLnB1c2goe1xuICAgICAgICBzZXZlcml0eTogXCJoaWdoXCIsXG4gICAgICAgIHRpdGxlOiBcIlRpbWVvdXQgZGV0ZWN0ZWRcIixcbiAgICAgICAgZGV0YWlsOiBcIkF0IGxlYXN0IG9uZSBldmVudCBpbmRpY2F0ZXMgdGhhdCBhIHRvb2wgb3IgZGVwZW5kZW5jeSBleGNlZWRlZCBpdHMgdGltZSBsaW1pdC5cIixcbiAgICAgICAgcmVjb21tZW5kYXRpb246IFwiQ2hlY2sgZGVwZW5kZW5jeSBoZWFsdGggYW5kIGxhdGVuY3kuIFNldCBhIGJvdW5kZWQgdGltZW91dCwgZW1pdCBkdXJhdGlvbiBtZXRyaWNzLCBhbmQgY29uc2lkZXIgYSBmYWxsYmFjayBmb3IgdGhpcyB0b29sLlwiXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGxvd2VyLmluY2x1ZGVzKFwicmV0cnlcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJyZXRyaWVzXCIpKSB7XG4gICAgICBmaW5kaW5ncy5wdXNoKHtcbiAgICAgICAgc2V2ZXJpdHk6IFwibWVkaXVtXCIsXG4gICAgICAgIHRpdGxlOiBcIlJldHJ5IGJlaGF2aW9yIGRldGVjdGVkXCIsXG4gICAgICAgIGRldGFpbDogXCJUaGUgdHJhY2UgbWVudGlvbnMgYSByZXRyeS4gUmVwZWF0ZWQgcmV0cmllcyBjYW4gYW1wbGlmeSBsYXRlbmN5IHdoZW4gdGhlIHVuZGVybHlpbmcgZmFpbHVyZSBpcyBwZXJzaXN0ZW50LlwiLFxuICAgICAgICByZWNvbW1lbmRhdGlvbjogXCJVc2UgY2FwcGVkIGV4cG9uZW50aWFsIGJhY2tvZmYgd2l0aCBqaXR0ZXIsIGFuZCByZXRyeSBvbmx5IGVycm9ycyB0aGF0IGFyZSBzYWZlIHRvIHJlcGVhdC5cIlxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChsb3dlci5pbmNsdWRlcyhcImludmFsaWQganNvblwiKSB8fCBsb3dlci5pbmNsdWRlcyhcInNjaGVtYVwiKSB8fCBsb3dlci5pbmNsdWRlcyhcInBhcnNlIGVycm9yXCIpKSB7XG4gICAgICByb290Q2F1c2UgPSBcIlRoZSBhZ2VudCBvdXRwdXQgbWF5IG5vdCBtYXRjaCB0aGUgZXhwZWN0ZWQgc3RydWN0dXJlXCI7XG4gICAgICBzdW1tYXJ5ID0gXCJUaGUgdHJhY2Ugc3VnZ2VzdHMgYSBzdHJ1Y3R1cmVkLW91dHB1dCBwYXJzaW5nIG9yIHZhbGlkYXRpb24gcHJvYmxlbS5cIjtcbiAgICAgIGZpbmRpbmdzLnB1c2goe1xuICAgICAgICBzZXZlcml0eTogXCJoaWdoXCIsXG4gICAgICAgIHRpdGxlOiBcIlN0cnVjdHVyZWQgb3V0cHV0IHZhbGlkYXRpb24gaXNzdWVcIixcbiAgICAgICAgZGV0YWlsOiBcIkEgSlNPTiwgc2NoZW1hLCBvciBwYXJzaW5nIGVycm9yIGFwcGVhcnMgaW4gdGhlIHRyYWNlLlwiLFxuICAgICAgICByZWNvbW1lbmRhdGlvbjogXCJWYWxpZGF0ZSBtb2RlbCBvdXRwdXQgYXQgdGhlIGJvdW5kYXJ5LCByZXR1cm4gdGhlIHZhbGlkYXRpb24gZXJyb3IgdG8gdGhlIGFnZW50LCBhbmQgY2FwIHJlcGFpciBhdHRlbXB0cy5cIlxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChsb3dlci5pbmNsdWRlcyhcInBlcm1pc3Npb25cIikgfHwgbG93ZXIuaW5jbHVkZXMoXCJ1bmF1dGhvcml6ZWRcIikgfHwgbG93ZXIuaW5jbHVkZXMoXCI0MDNcIikpIHtcbiAgICAgIGZpbmRpbmdzLnB1c2goe1xuICAgICAgICBzZXZlcml0eTogXCJoaWdoXCIsXG4gICAgICAgIHRpdGxlOiBcIkF1dGhvcml6YXRpb24gaXNzdWUgZGV0ZWN0ZWRcIixcbiAgICAgICAgZGV0YWlsOiBcIlRoZSB0cmFjZSBpbmNsdWRlcyBhIHBlcm1pc3Npb24gb3IgYXV0aG9yaXphdGlvbiBmYWlsdXJlLlwiLFxuICAgICAgICByZWNvbW1lbmRhdGlvbjogXCJWZXJpZnkgdGhlIHJ1bnRpbWUgaWRlbnRpdHksIHRvb2wgc2NvcGVzLCBhbmQgcmVzb3VyY2UtbGV2ZWwgcGVybWlzc2lvbnMuIEF2b2lkIGxvZ2dpbmcgc2VjcmV0cyBvciB0b2tlbnMuXCJcbiAgICAgIH0pO1xuICAgICAgaWYgKCFsb3dlci5pbmNsdWRlcyhcInRpbWVvdXRcIikpIHtcbiAgICAgICAgcm9vdENhdXNlID0gXCJBIHRvb2wgY2FsbCBtYXkgYmUgYmxvY2tlZCBieSBhdXRob3JpemF0aW9uXCI7XG4gICAgICAgIHN1bW1hcnkgPSBcIlRoZSB0cmFjZSBpbmNsdWRlcyBhIHBlcm1pc3Npb24tcmVsYXRlZCBmYWlsdXJlIHRoYXQgbWF5IHByZXZlbnQgdGhlIGFnZW50IGZyb20gdXNpbmcgYSB0b29sLlwiO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobG93ZXIuaW5jbHVkZXMoXCJsb29wXCIpIHx8IGxvd2VyLmluY2x1ZGVzKFwibWF4aW11bSBzdGVwc1wiKSB8fCBsb3dlci5pbmNsdWRlcyhcIm1heCBpdGVyYXRpb25zXCIpKSB7XG4gICAgICBmaW5kaW5ncy5wdXNoKHtcbiAgICAgICAgc2V2ZXJpdHk6IFwibWVkaXVtXCIsXG4gICAgICAgIHRpdGxlOiBcIlBvc3NpYmxlIGFnZW50IGxvb3Agb3Igc3RlcC1saW1pdCBoaXRcIixcbiAgICAgICAgZGV0YWlsOiBcIlRoZSB0cmFjZSBzdWdnZXN0cyByZXBlYXRlZCBhY3Rpb25zIG9yIGEgbWF4aW11bS1zdGVwIGxpbWl0LlwiLFxuICAgICAgICByZWNvbW1lbmRhdGlvbjogXCJBZGQgYSBjbGVhciBzdG9wIGNvbmRpdGlvbiwgZGV0ZWN0IHJlcGVhdGVkIHRvb2wvYWN0aW9uIHBhaXJzLCBhbmQgbG9nIHRoZSBhZ2VudCdzIGN1cnJlbnQgZ29hbC5cIlxuICAgICAgfSk7XG4gICAgICBpZiAoIWxvd2VyLmluY2x1ZGVzKFwidGltZW91dFwiKSkge1xuICAgICAgICByb290Q2F1c2UgPSBcIlRoZSBhZ2VudCBtYXkgYmUgc3R1Y2sgcmVwZWF0aW5nIGFjdGlvbnNcIjtcbiAgICAgICAgc3VtbWFyeSA9IFwiVGhlIHRyYWNlIHN1Z2dlc3RzIGEgbG9vcCBvciBhIHJ1biB0aGF0IHJlYWNoZWQgaXRzIHN0ZXAgbGltaXQuXCI7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChmaW5kaW5ncy5sZW5ndGggPT09IDApIHtcbiAgICAgIGZpbmRpbmdzLnB1c2goe1xuICAgICAgICBzZXZlcml0eTogXCJsb3dcIixcbiAgICAgICAgdGl0bGU6IFwiTm8gbWF0Y2hpbmcgc2lnbmF0dXJlIGZvdW5kXCIsXG4gICAgICAgIGRldGFpbDogXCJUaGUgY3VycmVudCBwcm90b3R5cGUgY2hlY2tzIGEgc21hbGwgc2V0IG9mIGNvbW1vbiBmYWlsdXJlIHBhdHRlcm5zLlwiLFxuICAgICAgICByZWNvbW1lbmRhdGlvbjogXCJJbmNsdWRlIHRoZSBmdWxsIHRvb2wgcmVxdWVzdC9yZXNwb25zZSwgZXhjZXB0aW9uIG1lc3NhZ2UsIGFuZCBydW4gSUQgdG8gbWFrZSB0aGUgdHJhY2UgbW9yZSBhY3Rpb25hYmxlLlwiXG4gICAgICB9KTtcbiAgICB9XG4gICAgICAgIC8vIEdlbWluaSBhZGRzIGFuIEFJIGludmVzdGlnYXRpb247IGV4aXN0aW5nIHJ1bGUtYmFzZWQgcmVzdWx0cyByZW1haW4gdGhlIGZhbGxiYWNrLlxuICAgIGxldCBhaVN1bW1hcnkgPSBzdW1tYXJ5O1xuICAgIGxldCBhaVJvb3RDYXVzZSA9IHJvb3RDYXVzZTtcbiAgICBsZXQgYWlGaW5kaW5ncyA9IGZpbmRpbmdzO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFpID0gbmV3IEdvb2dsZUdlbkFJKHtcbiAgICAgICAgYXBpS2V5OiBwcm9jZXNzLmVudi5HRU1JTklfQVBJX0tFWSxcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFpLm1vZGVscy5nZW5lcmF0ZUNvbnRlbnQoe1xuICAgICAgICBtb2RlbDogXCJnZW1pbmktMy4xLWZsYXNoLWxpdGVcIixcbiAgICAgICAgY29udGVudHM6IGBcbllvdSBhcmUgVHJhY2VQaWxvdCwgYW4gYXBwbGljYXRpb24gdHJhY2UgaW52ZXN0aWdhdG9yLlxuQW5hbHl6ZSB0aGUgbG9ncyBiZWxvdy4gVXNlIG9ubHkgZXZpZGVuY2UgcHJlc2VudCBpbiB0aGUgbG9ncy5cbkRvIG5vdCBpbnZlbnQgZXZlbnRzIG9yIGNsYWltIGNlcnRhaW50eSB3aGVuIHRoZSBldmlkZW5jZSBpcyBpbmNvbmNsdXNpdmUuXG5SZXR1cm4gT05MWSB2YWxpZCBKU09OIHdpdGggdGhpcyBleGFjdCBzaGFwZTpcbntcbiAgXCJzdW1tYXJ5XCI6IFwiYnJpZWYgZXhwbGFuYXRpb25cIixcbiAgXCJyb290Q2F1c2VcIjogXCJsaWtlbHkgY2F1c2UsIG9yIHNheSBpdCBpcyB1bmNsZWFyXCIsXG4gIFwiZmluZGluZ3NcIjogW1xuICAgIHtcbiAgICAgIFwic2V2ZXJpdHlcIjogXCJoaWdoXCIsXG4gICAgICBcInRpdGxlXCI6IFwic2hvcnQgdGl0bGVcIixcbiAgICAgIFwiZGV0YWlsXCI6IFwiZXZpZGVuY2UgZnJvbSB0aGUgdHJhY2VcIixcbiAgICAgIFwicmVjb21tZW5kYXRpb25cIjogXCJuZXh0IGRlYnVnZ2luZyBzdGVwXCJcbiAgICB9XG4gIF1cbn1cblNldmVyaXR5IG11c3QgYmUgXCJoaWdoXCIsIFwibWVkaXVtXCIsIG9yIFwibG93XCIuXG5JZiB0aGVyZSBpcyBubyBjbGVhciBpc3N1ZSwgcmV0dXJuIG9uZSBsb3ctc2V2ZXJpdHkgZmluZGluZy5cblxuTG9nczpcbiR7bG9nc31cbiAgICAgICAgYCxcbiAgICAgICAgY29uZmlnOiB7XG4gICAgICAgICAgcmVzcG9uc2VNaW1lVHlwZTogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgdGV4dCA9IHJlc3BvbnNlLnRleHQ7XG4gICAgICBpZiAodGV4dCkge1xuICAgICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xuXG4gICAgICAgIGlmIChcbiAgICAgICAgICB0eXBlb2YgcGFyc2VkLnN1bW1hcnkgPT09IFwic3RyaW5nXCIgJiZcbiAgICAgICAgICB0eXBlb2YgcGFyc2VkLnJvb3RDYXVzZSA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgICAgIEFycmF5LmlzQXJyYXkocGFyc2VkLmZpbmRpbmdzKVxuICAgICAgICApIHtcbiAgICAgICAgICBhaVN1bW1hcnkgPSBwYXJzZWQuc3VtbWFyeTtcbiAgICAgICAgICBhaVJvb3RDYXVzZSA9IHBhcnNlZC5yb290Q2F1c2U7XG4gICAgICAgICAgYWlGaW5kaW5ncyA9IHBhcnNlZC5maW5kaW5ncztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAvLyBLZWVwIHRoZSBydWxlLWJhc2VkIGFuYWx5c2lzIGlmIEdlbWluaSBpcyB1bmF2YWlsYWJsZSBvciByZXR1cm5zIGludmFsaWQgZGF0YS5cbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJHZW1pbmkgaW52ZXN0aWdhdGlvbiBmYWlsZWQ6XCIsIGVycm9yKTtcbiAgICB9XG4gICAgY29uc3QgdHJhY2UgPSBwYXJzZVRyYWNlKGxvZ3MpLnNsaWNlKC0zMCk7XG4gICAgY29uc3QgZXJyb3JDb3VudCA9IHRyYWNlLmZpbHRlcihlID0+IGUubGV2ZWwgPT09IFwiRVJST1JcIikubGVuZ3RoO1xuICAgIGNvbnN0IHJ1bklkID0gYFRQLSR7RGF0ZS5ub3coKS50b1N0cmluZygzNikudG9VcHBlckNhc2UoKX1gO1xuXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHtcbiAgICAgIHJ1bklkLFxuICAgICAgc3RhdHVzOiBlcnJvckNvdW50ID8gXCJuZWVkc19hdHRlbnRpb25cIiA6IFwicmV2aWV3ZWRcIixcbiAgICAgIHN1bW1hcnk6IGFpU3VtbWFyeSxcbiAgICAgIHJvb3RDYXVzZTogYWlSb290Q2F1c2UsXG4gICAgICBmaW5kaW5nczogYWlGaW5kaW5ncyxcbiAgICAgIHRyYWNlXG4gICAgfSk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBOZXh0UmVzcG9uc2UuanNvbih7IGVycm9yOiBcIkludmFsaWQgcmVxdWVzdC4gU2VuZCBKU09OIHdpdGggYSBsb2dzIHN0cmluZy5cIiB9LCB7IHN0YXR1czogNDAwIH0pO1xuICB9XG59XG4iXSwibmFtZXMiOlsiR29vZ2xlR2VuQUkiLCJOZXh0UmVzcG9uc2UiLCJwYXJzZVRyYWNlIiwibG9ncyIsInNwbGl0IiwiZmlsdGVyIiwiQm9vbGVhbiIsInNsaWNlIiwibWFwIiwibGluZSIsImluZGV4IiwibWF0Y2giLCJ0aW1lIiwibGV2ZWwiLCJ0b1VwcGVyQ2FzZSIsIm1lc3NhZ2UiLCJTdHJpbmciLCJwYWRTdGFydCIsInRlc3QiLCJQT1NUIiwicmVxdWVzdCIsImJvZHkiLCJqc29uIiwidHJpbSIsImVycm9yIiwic3RhdHVzIiwibGVuZ3RoIiwibG93ZXIiLCJ0b0xvd2VyQ2FzZSIsImZpbmRpbmdzIiwicm9vdENhdXNlIiwic3VtbWFyeSIsImluY2x1ZGVzIiwicHVzaCIsInNldmVyaXR5IiwidGl0bGUiLCJkZXRhaWwiLCJyZWNvbW1lbmRhdGlvbiIsImFpU3VtbWFyeSIsImFpUm9vdENhdXNlIiwiYWlGaW5kaW5ncyIsImFpIiwiYXBpS2V5IiwicHJvY2VzcyIsImVudiIsIkdFTUlOSV9BUElfS0VZIiwicmVzcG9uc2UiLCJtb2RlbHMiLCJnZW5lcmF0ZUNvbnRlbnQiLCJtb2RlbCIsImNvbnRlbnRzIiwiY29uZmlnIiwicmVzcG9uc2VNaW1lVHlwZSIsInRleHQiLCJwYXJzZWQiLCJKU09OIiwicGFyc2UiLCJBcnJheSIsImlzQXJyYXkiLCJjb25zb2xlIiwidHJhY2UiLCJlcnJvckNvdW50IiwiZSIsInJ1bklkIiwiRGF0ZSIsIm5vdyIsInRvU3RyaW5nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/investigate/route.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/google-auth-library","vendor-chunks/ws","vendor-chunks/gaxios","vendor-chunks/jws","vendor-chunks/retry","vendor-chunks/json-bigint","vendor-chunks/google-logging-utils","vendor-chunks/gcp-metadata","vendor-chunks/ecdsa-sig-formatter","vendor-chunks/@google","vendor-chunks/safe-buffer","vendor-chunks/p-retry","vendor-chunks/jwa","vendor-chunks/extend","vendor-chunks/buffer-equal-constant-time","vendor-chunks/bignumber.js","vendor-chunks/base64-js"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Finvestigate%2Froute&page=%2Fapi%2Finvestigate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Finvestigate%2Froute.ts&appDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CAKSHAYA%5CDownloads%5Ctracepilot-nextjs%20(1)%5Ctracepilot-nextjs&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();